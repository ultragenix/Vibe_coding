# Project Configuration

## Multi-Agent Workflow

This project uses a multi-agent development workflow with 6 specialized agents.
Always read the relevant coordination files before taking action.

## Coordination Files (ALWAYS read these first)
- `PLAN.md` — Project plan, parts breakdown, acceptance criteria (source of truth)
- `STATE.md` — Live project state, progress, history, alerts
- `CORRECTIONS.md` — Pending corrections backlog

## Available Agents (in .claude/agents/)
| Agent | Role | When to use |
|-------|------|-------------|
| `brief` | Guide de cadrage | AVANT le plan, pour definir le besoin |
| `architect` | Plan & structure | Project start, plan revision |
| `developer` | Implementation | Code a part from PLAN.md |
| `qa-security` | Test & audit | After dev completes a part |
| `validator` | Integration check | After QA approves a part |
| `tech-lead` | Refactoring | Every 3 parts or on demand |
| `documentalist` | Documentation | After validation or on demand |

## Quick Commands (in .claude/commands/)
| Command | Action |
|---------|--------|
| `/project:brief` | Define your project step by step (guided) |
| `/project:plan` | Start or revise the project plan |
| `/project:dev` | Implement the next part |
| `/project:qa` | Audit the latest part |
| `/project:validate` | Final validation check |
| `/project:refactor` | Periodic code cleanup |
| `/project:doc` | Update documentation |
| `/project:status` | View project progress |

## Workflow Sequence
```
/project:brief → /project:plan → /project:dev → /project:qa → /project:validate
(optional)        ↑                                    |
                  └──── (if rejected) ─────────────────┘

Every 3 validated parts: /project:refactor → /project:doc
```

## Development Rules
- Always commit after each successful agent step
- Use conventional commits: feat(part-N), fix(part-N), refactor, docs
- Never modify files outside the current part's scope
- Always check STATE.md before starting work
- Maximum 3 correction attempts before escalating to architect

## Code Standards
- TypeScript strict mode / Python type hints
- Functions < 25 lines, single responsibility
- Explicit error handling, no empty catches
- English variable/function names
- French comments and documentation
