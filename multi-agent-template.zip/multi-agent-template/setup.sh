#!/bin/bash
# ============================================================
# Multi-Agent Workflow — Setup Script
# Cree la structure complete pour un nouveau projet
# Usage : ./setup.sh [nom-du-projet]
# ============================================================

set -e

PROJECT_NAME="${1:-mon-projet}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "🏗️  Creation du projet : $PROJECT_NAME"
echo "================================================"

# Creer le dossier projet
mkdir -p "$PROJECT_NAME"
cd "$PROJECT_NAME"

# Initialiser git
git init -q
echo "✅ Git initialise"

# Creer la structure
mkdir -p .claude/agents
mkdir -p .claude/commands
mkdir -p REPORTS
mkdir -p docs
mkdir -p src
mkdir -p tests/unit
mkdir -p tests/qa
echo "✅ Structure de dossiers creee"

# Copier les agents
cp "$SCRIPT_DIR/.claude/agents/"*.md .claude/agents/
echo "✅ 7 agents copies dans .claude/agents/"

# Copier les commandes
cp "$SCRIPT_DIR/.claude/commands/"*.md .claude/commands/
echo "✅ 8 commandes copiees dans .claude/commands/"

# Copier CLAUDE.md
cp "$SCRIPT_DIR/CLAUDE.md" ./CLAUDE.md
echo "✅ CLAUDE.md copie"

# Copier les templates
cp "$SCRIPT_DIR/templates/CORRECTIONS.template.md" ./CORRECTIONS.md
echo "✅ CORRECTIONS.md initialise"

# Creer .gitignore
cat > .gitignore << 'EOF'
node_modules/
.env
.env.*
!.env.example
dist/
build/
*.log
.DS_Store
__pycache__/
*.pyc
.venv/
EOF
echo "✅ .gitignore cree"

# Creer .env.example
cat > .env.example << 'EOF'
# Variables d'environnement du projet
# Copier ce fichier en .env et remplir les valeurs

# DATABASE_URL=postgresql://user:password@localhost:5432/dbname
# JWT_SECRET=your-secret-key
# PORT=3000
EOF
echo "✅ .env.example cree"

# Premier commit
git add -A
git commit -q -m "feat: initialisation du projet avec workflow multi-agent"
echo "✅ Premier commit effectue"

echo ""
echo "================================================"
echo "🎉 Projet $PROJECT_NAME pret !"
echo ""
echo "Prochaines etapes :"
echo "  cd $PROJECT_NAME"
echo "  claude"
echo "  /project:brief   ← Definir ton besoin (guide)"
echo "  /project:plan    ← Planifier le projet"
echo "================================================"
