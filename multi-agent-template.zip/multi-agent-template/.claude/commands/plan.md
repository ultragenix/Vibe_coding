---
description: "Launch the Architect agent to plan or revise the project"
---

Use the architect agent. 

If PLAN.md does not exist, start in CREATION mode: ask questions to understand the project, then create PLAN.md and STATE.md.

If PLAN.md exists, start in REVISION mode: read STATE.md, understand the current state, and discuss needed changes with me.

Context: $ARGUMENTS
