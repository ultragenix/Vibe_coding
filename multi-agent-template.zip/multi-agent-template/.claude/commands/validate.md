---
description: "Launch the Validator for final integration check on a QA-approved part"
---

Use the validator agent. Read STATE.md to identify which part has QA ✅ but not yet Validated. Run full validation: integration tests, acceptance criteria, non-regression, coherence check, verdict.

Part to validate: $ARGUMENTS
