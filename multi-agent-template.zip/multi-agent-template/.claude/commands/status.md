---
description: "Show project status: progress, current state, next actions"
---

Read STATE.md, PLAN.md, and CORRECTIONS.md. Give me a concise status report:

1. Overall progress (X/Y parts, percentage)
2. Current state of each part (one-line summary)
3. Active corrections/blockers from CORRECTIONS.md
4. Next recommended action
5. Any alerts or risks

Be concise, use a table format.
