---
description: "Launch the Tech Lead for periodic refactoring and code cleanup"
---

Use the tech-lead agent. Analyze the full codebase, identify duplication, inconsistencies, and tech debt. Apply refactoring with test verification after each change.

Focus area: $ARGUMENTS
