Use the "Brief - Guide de cadrage projet" agent to guider l'utilisateur dans la definition de son projet.

L'agent va poser des questions simples, une par une, pour comprendre le besoin. A la fin, il genere un resume structure que l'utilisateur peut copier-coller dans /project:plan.

C'est la PREMIERE etape avant de planifier. L'utilisateur n'a pas besoin de savoir quoi demander — l'agent le guide.

$ARGUMENTS
