---
description: "Launch the Documentalist to update project documentation"
---

Use the documentalist agent. Read STATE.md to understand what changed recently, then update all relevant documentation (README.md, API.md, ARCHITECTURE.md).

Focus: $ARGUMENTS
