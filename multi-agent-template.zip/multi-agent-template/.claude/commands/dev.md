---
description: "Launch the Developer agent to implement a part from PLAN.md"
---

Use the developer agent to implement a part from PLAN.md.

First read PLAN.md and STATE.md. If I specified a part number, implement that part. If not, identify the next part that is ready to be implemented (dependencies met, not yet started).

Follow the developer agent's full process: check prerequisites, announce plan, implement, test, report, update STATE.md.

Part to implement: $ARGUMENTS
