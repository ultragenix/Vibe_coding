---
description: "Launch QA & Security audit on a completed part"
---

Use the qa-security agent to audit the most recently developed part.

Read STATE.md to identify which part has Dev ✅ but not yet QA. Run the full audit process: independent tests, security checklist, quality audit, verdict.

Part to audit: $ARGUMENTS
